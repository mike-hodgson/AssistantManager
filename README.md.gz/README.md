Place static assets for GitHub Pages deployment here. Ensure `index.html` and `manifest.json` are present when publishing the Blazor WASM build output.
